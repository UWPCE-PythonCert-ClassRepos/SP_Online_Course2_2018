"""
Sample donors
"""

def get_donors():
    donors = [
        {
            'name': 'Thomas H',
            'donations': '500',
            'average': '500',
            'count': '1'
        },
        {
            'name': 'Ted H',
            'donations': '10',
            'average': '5',
            'count': '2'
        },
        {
            'name': 'Bailey K',
            'donations': '100',
            'average': '20',
            'count': '5'
        },
    ]
    return donors